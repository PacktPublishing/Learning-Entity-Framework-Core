﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Extensions;
using MyFirstEfCoreApp.Models;

namespace MyFirstEfCoreApp.Data
{
    public static class DbInit
    {
        public static void InitializeWithFakeData(AppDbContext context)
        {
            context.Database.EnsureCreated();

            if(!context.Contacts.Any())
            {
                context.Contacts.Add(new Contact() { FirstName = "John", LastName = "Smith", Email = "john.smith@outlook.com" });
                context.Contacts.Add(new Contact() { FirstName = "Jane", LastName = "Doe", Email = "jane.doe@gmail.com" });
                context.Contacts.Add(new Contact() { FirstName = "Mark", LastName = "Doe", Email = "mark.doe@gmail.com" });
            }

            if(!context.ToDos.Any())
            {
                context.ToDos.Add(new ToDo() { Text = "Wash the dishes", Completed = true });
                context.ToDos.Add(new ToDo() { Text = "Take out the trash", Completed = false });
                context.ToDos.Add(new ToDo() { Text = "Study for exams", Completed = false });
            }

            context.SaveChanges();
        }
    }
}
